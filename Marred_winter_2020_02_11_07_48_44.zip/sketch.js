xRad=20;
yRad=20;
pos

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  for(var x=xRad/2; x < width; x+=xRad){
      for(var y=yRad/2; y < height; y+=yRad){
        fill("pink")
        ellipse(x, y, (mouseX-x)/20, (mouseY-y)/20);}     
  }
  
for(var x=xRad/2; x < width; x+=xRad){
      for(var y=yRad/2; y < height; y+=yRad){
        fill("blue")
          ellipse(mouseX, mouseY, xRad, yRad);
      } 
  }
 

}